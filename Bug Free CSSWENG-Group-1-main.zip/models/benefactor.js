const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const BenefactorScheme = new Schema({
    
});

module.exports = mongoose.model("Benefactor", BenefactorScheme, "benefactors");